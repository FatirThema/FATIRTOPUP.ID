

<?php 

$link_ig = "https://instagram.com/maha4tir315";
$link_fb = "https://www.youtube.com/fatirdevillan.devbase";
$link_t = "https://tiktok.com/fatirdevilanoffcial";

 ?>

<div class="container-fluid mt-5">
	<div class="row">
		<div class="col-md-4 col-12 text-center mb-4 p-5"style="background-color: rgba(0, 0, 0, 1);">
			<h5>𝗕𝗘𝗥𝗟𝗔𝗡𝗚𝗚𝗔𝗡𝗔𝗡</h5>
			<h3>𝗜𝗞𝗨𝗧𝗜 𝗞𝗔𝗠𝗜 𝗦𝗘𝗞𝗔𝗥𝗔𝗡𝗚 𝗝𝗨𝗚𝗔</h3>
			<div class="row justify-content-center">
				
				<div style="width:30%"><a href="<?= $link_ig ?>"><img src="img/ig.png" style="width: 60px" alt=""></a></div>
				<div style="width:30%"><a href="<?= $link_fb ?>"><img class="mt-1" src="img/fb.png" style="width: 55px" alt=""></a></div>
				<div style="width:30%"><a href="<?= $link_t ?>"><img src="img/t.png" style="width: 60px" alt=""></a></div>
				
			</div>
		</div>

		<div class="col-md-4 col-12 mb-4">
			<h5><?= $data->𝗙𝗔𝗧𝗜𝗥𝗧𝗢𝗣𝗨𝗣.𝗜𝗗></h5>
			  <div style="width: 80px; border-radius: 20px; margin-left: 5px; height: 5px; padding:3px; background-color: red; color: red;"></div>
			<p><?= $data->𝗙𝗔𝗧𝗜𝗥𝗧𝗢𝗣𝗨𝗣.𝗜𝗗> 𝗮𝗱𝗮𝗹𝗮𝗵 𝘀𝗶𝘁𝘂𝘀 𝘄𝗲𝗯 𝘁𝗼𝗽 𝘂𝗽 𝗴𝗮𝗺𝗲 𝗿𝗲𝘀𝗺𝗶 𝗱𝗮𝗻 𝗺𝗮𝗿𝗸𝗲𝘁 𝗱𝗶𝗴𝗶𝘁𝗮𝗹 𝘆𝗮𝗻𝗴 𝗮𝗺𝗮𝗻 𝟭𝟬𝟬% 𝗱𝗮𝗻 𝗸𝗮𝗺𝗶 𝗺𝗲𝗻𝘆𝗲𝗱𝗶𝗮𝗸𝗮𝗻 𝗯𝗮𝗻𝘆𝗮𝗸 𝗽𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻 𝗱𝗮𝗻 𝗷𝘂𝗴𝗮 𝗹𝗮𝘆𝗮𝗻𝗮𝗻 𝘀𝗲𝗽𝗲𝗿𝘁𝗶 𝗷𝘂𝗮𝗹 𝗯𝗲𝗹𝗶 𝗮𝗸𝘂𝗻 𝗴𝗮𝗺𝗲 - 𝘂𝗽𝗴𝗿𝗮𝗱𝗲 𝗮𝗰𝗰𝗼𝘂𝗻𝘁 𝗽𝗿𝗲𝗺𝗶𝘂𝗺 𝗱𝗮𝗻 𝗹𝗮𝗶𝗻-𝗹𝗮𝗶𝗻. 𝗞𝗮𝗺𝗶 𝗯𝗲𝗿𝗱𝗶𝗿𝗶 𝘀𝗲𝗺𝗲𝗻𝗷𝗮𝗸 𝘁𝗮𝗵𝘂𝗻 𝟮𝟬𝟮𝟮</p>
			
		</div>

		<div class="col-md-4 col-12 mb-4">
			<h5>𝗢𝗣𝗦𝗜 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡</h5>
			  <div style="width: 80px; border-radius: 20px; margin-left: 5px; height: 5px; padding:3px; background-color: red; color: red;"></div>
<br>
			<a style="color: white" href="https://wa.me/<?= $data->https://wa.me/6285881867694>?text=bang+saya+mau+kasih+pembayarannya"><p>𝗖𝗵𝗮𝘁 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽</p></a>
			
		</div>


	</div>
</div>



<div class="footer text-center">
	<p>𝗖𝗼𝗽𝘆𝗿𝗶𝗴𝗵𝘁t 2025 𝗕𝘆 <?= $data->𝗙𝗔𝗧𝗜𝗥𝗧𝗢𝗣𝗨𝗣.𝗜𝗗></p>
</div>